module decode_new (
input [31:0] joy1, joy2, status,
input [7:0] mod, sw0, sw1, sw2, sw3,
input [4:0] moon_dial,
input [5:0] darkplnt_dial,
input moon_dial_dir,
output [75:0] observation
);
wire [31:0] joy = joy1 | joy2;
wire [7:0] sw[8];
assign sw[0]=sw0; assign sw[1]=sw1; assign sw[2]=sw2; assign sw[3]=sw3;
wire m_up1     = joy1[3];
wire m_down1   = joy1[2];
wire m_left1   = joy1[1];
wire m_right1  = joy1[0];
wire m_fire1a  = joy1[4];
wire m_fire1b  = joy1[5];
wire m_fire1c  = joy1[6];
wire m_fire1d  = joy1[7];
wire m_fire1e  = joy1[8];
wire m_spccw1  = joy1[30];
wire m_spcw1   = joy1[31];

wire m_up2     = joy2[3];
wire m_down2   = joy2[2];
wire m_left2   = joy2[1];
wire m_right2  = joy2[0];
wire m_fire2a  = joy2[4];
wire m_fire2b  = joy2[5];
wire m_fire2c  = joy2[6];
wire m_fire2d  = joy2[7];
wire m_fire2e  = joy2[8];
wire m_spccw2  = joy2[30];
wire m_spcw2   = joy2[31];

wire m_up      = m_up1       | m_up2;
wire m_down    = m_down1     | m_down2;
wire m_left    = m_left1     | m_left2;
wire m_right   = m_right1    | m_right2;
wire m_fire_a  = m_fire1a    | m_fire2a;
wire m_fire_b  = m_fire1b    | m_fire2b;
wire m_fire_c  = m_fire1c    | m_fire2c;
wire m_fire_d  = m_fire1d    | m_fire2d;
wire m_fire_e  = m_fire1e    | m_fire2e;
wire m_spccw   = m_spccw1    | m_spccw2;
wire m_spcw    = m_spcw1     | m_spcw2;

wire m_start1  = joy[8];
wire m_start2  = joy[9];
wire m_coin    = joy[10];
wire m_pause   = joy[11];


localparam mod_scramble = 0;
localparam mod_amidar   = 1;
localparam mod_frogger  = 2;
localparam mod_scobra   = 3;
localparam mod_tazman   = 4;
localparam mod_armorcar = 5;
localparam mod_moonwar  = 6;
localparam mod_spdcoin  = 7;
localparam mod_calipso  = 8;
localparam mod_darkplnt = 9;
localparam mod_anteater = 10;
localparam mod_losttomb = 11;
localparam mod_theend   = 12;
localparam mod_mars     = 13;
localparam mod_stratgyx = 14;
localparam mod_turtles  = 15;
localparam mod_minefld  = 16;
localparam mod_rescue   = 17;
localparam mod_mimonkey = 18;
localparam mod_cavelon  = 19;
localparam mod_superbon = 20;


reg       landscape;
reg       has_spinner;
reg       fourfire;
reg       galaxian_video;
reg [7:0] hwsel;
reg [7:0] input0;
reg [7:0] input1;
reg [7:0] input2;
reg [7:0] input3;
always @(*) begin
	has_spinner = 0;
	fourfire = 0;
	landscape = 0;
	galaxian_video = 0;
	hwsel  = 0;
	input0 = ~{ m_coin, 1'b0, m_left, m_right, m_fire_a, 1'b0, m_fire_b, m_up };
	input1 = ~{ m_start1, m_start2, m_left, m_right, m_fire_a, m_fire_b, 2'b00 };
	input2 = ~{ 1'b0, m_down, 1'b0, m_up, 3'b000, m_down };
	input3 = 8'hFF;

	case (mod)
		mod_frogger:
			begin
				hwsel = 1;
			end
		mod_scobra:
			begin
				hwsel = 2;
			end
		mod_superbon:
			begin
				hwsel = 2;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, m_start1, m_start2 };
				input1 = ~{ 1'b0, m_fire_a, 2'b00, m_fire_b, 3'b000 };
				input2 = 8'hFF;
			end
		mod_tazman:
			begin
				hwsel = 2;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, m_fire_a, m_fire_b };
				input1 = 8'hFF;
				input2 = ~{ 1'b0, m_start2, 2'b00, 3'b000, m_start1 };
			end
		mod_armorcar:
			begin
				hwsel = 2;
			end
		mod_moonwar:
			begin
				hwsel = 2;
				has_spinner = 1;
				input0 = ~{ m_coin, 1'b0, 1'b0, moon_dial_dir, moon_dial[4:1] };
				input1 = ~{ m_fire_a, m_fire_b, m_fire_c, m_fire_d, m_start2, m_start1, 2'b00 };
				input2 = 8'hFF;
			end
		mod_spdcoin:
			begin
				hwsel = 2;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_start2, 1'b0, m_start1, 1'b0 };
				input1 = 8'hFF;
				input2 = 8'hFF;
			end
		mod_calipso:
			begin
				hwsel = 3;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, 1'b0, m_start2 | m_fire_a };
				input1 = ~{ 1'b0, 1'b0, m_left, m_right, m_down, m_up, 1'b0, 1'b0 };
				input2 = ~{ 5'b00000, 2'b00, m_fire_a | m_start1 };
			end
		mod_darkplnt:
			begin
				hwsel = 4;
				landscape = 1;
				has_spinner = 1;
				input0 = ~{ m_coin, 1'b0, 3'b000, m_start2 | m_fire_b, m_start1 | m_fire_a, m_fire_c };
				input1 = { darkplnt_dial, 2'b11 };
				input2 = 8'hFF;
			end
		mod_anteater:
			begin
				hwsel = 6;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, 1'b0, m_fire_a };
				input1 = ~{ 1'b0, m_fire_a, m_left, m_right, m_up, m_down, 2'b00 };
				input2 = ~{ 1'b0, m_start2, 2'b00, 3'b000, m_start1 };
			end
		mod_losttomb:
			begin
				hwsel = 7;
				fourfire = 1;
				input0 = status[7] ?
						 ~{ m_coin, 1'b0, m_left1, m_right1, m_down1, m_up1, m_start1, m_start2 }:
						 ~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, m_start1, m_start2 };
				input1 = status[7] ?
				         ~{ 1'b0, m_fire_e,          m_left2, m_right2, m_down2, m_up2, 2'b00 }:
						 status[6] ?
				         ~{ 1'b0, m_fire_e|m_fire_a, m_left,   m_right,  m_down,   m_up,     2'b00 }:
				         ~{ 1'b0, m_fire_e,          m_fire_d, m_fire_a, m_fire_b, m_fire_c, 2'b00 };
				input2 = 8'hFF;
			end
		mod_theend:
			begin
				galaxian_video = 1;
			end
		mod_mars:
			begin
				hwsel = 10;
				fourfire = 1;
				if(status[6]) begin
					input0 = ~{ m_coin, 1'b0, m_left, m_right, m_left, m_right, 1'b0, m_up };
					input1 = ~{ m_start1, m_start2, m_left, m_right, m_left, m_right, 2'b00 };
					input2 = ~{ m_up, m_down, m_down, m_up, 3'b000, m_down };
					input3 = ~{ m_up, 1'b0, m_down, 5'b00000 };
				end
				else if (status[7]) begin
					input0 = ~{ m_coin, 1'b0, m_left1, m_right1, m_left2, m_right2, 1'b0, m_up1 };
					input1 = ~{ m_start1, m_start2, m_left1, m_right1, m_left2, m_right2, 2'b00 };
					input2 = ~{ m_up2, m_down1, m_down2, m_up1, 3'b000, m_down1 };
					input3 = ~{ m_up2, 1'b0, m_down2, 5'b00000 };
				end
				else begin
					input0 = ~{ m_coin, 1'b0, m_left, m_right, m_fire_d, m_fire_a, 1'b0, m_up };
					input1 = ~{ m_start1, m_start2, m_left, m_right, m_fire_d, m_fire_a, 2'b00 };
					input2 = ~{ m_fire_c, m_down, m_fire_b, m_up, 3'b000, m_down };
					input3 = ~{ m_fire_c, 1'b0, m_fire_b, 5'b00000 };
				end
			end
		mod_stratgyx:
			begin
				hwsel = 5;
				landscape = 1;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_fire_a, 1'b0, m_fire_b, m_up };
				input1 = ~{ m_start1, m_start2, m_left, m_right, m_fire_a, m_fire_b, 2'b00 };
				input2 = ~{ m_fire_c, m_down, m_fire_c, m_up, 3'b000, m_down };
			end
		mod_turtles:
			begin
				hwsel = 11;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_fire_a, 2'b00, m_up };
				input1 = ~{ m_start1, m_start2, m_left, m_right, m_fire_a, 3'b000 };
				input2 = ~{ 1'b0, m_down, 1'b0, m_up, 3'b000, m_down };
			end
		mod_minefld:
			begin
				hwsel = 8;
				fourfire = 1;
				input0 = status[7] ? ~{ m_coin, 1'b0, m_left1, m_right1, m_down1, m_up1, 1'b0, m_start1 } :
						~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, 1'b0, m_start1 };
				input1 = status[7] ? ~{ 2'b00, m_left2, m_right2, m_down2, m_up2, 2'b00 } :
						status[6] ? ~{ 2'b00, m_left, m_right, m_down, m_up, 2'b00 } : 
						~{ 2'b00, m_fire_d, m_fire_a, m_fire_b, m_fire_c, 2'b00 };
				input2 = ~{ 1'b0, m_start2, 2'b00, 3'b000, m_start1 };
			end
		mod_rescue:
			begin
				hwsel = 9;
				fourfire = 1;
				input0 = status[7] ? ~{ m_coin, 1'b0, m_left1, m_right1, m_down1, m_up1, 1'b0, m_start1 } :
						~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, 1'b0, m_start1 };
				input1 = status[7] ? ~{ 2'b00, m_left2, m_right2, m_down2, m_up2, 2'b00 } :
						status[6] ? ~{ 2'b00, m_left, m_right, m_down, m_up, 2'b00 } : 
						~{ 2'b00, m_fire_d, m_fire_a, m_fire_b, m_fire_c, 2'b00 };
				input2 = ~{ 1'b0, m_start2, 2'b00, 3'b000, m_start1 };
			end
		mod_mimonkey:
			begin
				hwsel = 12;
			end
		mod_cavelon:
			begin
				hwsel = 13;
			end
		default:;
	endcase
end
wire [7:0] pa = sw[0] & input0;
wire [7:0] pb = sw[1] & input1;
wire [7:0] pc = sw[2] & input2;
wire [7:0] pd = sw[3] & input3;
assign observation = {landscape, has_spinner, fourfire, galaxian_video, hwsel,
input0, input1, input2, input3, pa, pb, pc, pd};
endmodule

module decode_old (
input [31:0] joy1, joy2, status,
input [7:0] mod, sw0, sw1, sw2, sw3,
input [4:0] moon_dial,
input [5:0] darkplnt_dial,
input moon_dial_dir,
output [75:0] observation
);
wire [31:0] joy = joy1 | joy2;
wire [7:0] sw[8];
assign sw[0]=sw0; assign sw[1]=sw1; assign sw[2]=sw2; assign sw[3]=sw3;
wire m_up1     = joy1[3];
wire m_down1   = joy1[2];
wire m_left1   = joy1[1];
wire m_right1  = joy1[0];
wire m_fire1a  = joy1[4];
wire m_fire1b  = joy1[5];
wire m_fire1c  = joy1[6];
wire m_fire1d  = joy1[7];
wire m_fire1e  = joy1[8];
wire m_spccw1  = joy1[30];
wire m_spcw1   = joy1[31];

wire m_up2     = joy2[3];
wire m_down2   = joy2[2];
wire m_left2   = joy2[1];
wire m_right2  = joy2[0];
wire m_fire2a  = joy2[4];
wire m_fire2b  = joy2[5];
wire m_fire2c  = joy2[6];
wire m_fire2d  = joy2[7];
wire m_fire2e  = joy2[8];
wire m_spccw2  = joy2[30];
wire m_spcw2   = joy2[31];

wire m_up      = m_up1       | m_up2;
wire m_down    = m_down1     | m_down2;
wire m_left    = m_left1     | m_left2;
wire m_right   = m_right1    | m_right2;
wire m_fire_a  = m_fire1a    | m_fire2a;
wire m_fire_b  = m_fire1b    | m_fire2b;
wire m_fire_c  = m_fire1c    | m_fire2c;
wire m_fire_d  = m_fire1d    | m_fire2d;
wire m_fire_e  = m_fire1e    | m_fire2e;
wire m_spccw   = m_spccw1    | m_spccw2;
wire m_spcw    = m_spcw1     | m_spcw2;

wire m_start1  = joy[8];
wire m_start2  = joy[9];
wire m_coin    = joy[10];
wire m_pause   = joy[11];


localparam mod_scramble = 0;
localparam mod_amidar   = 1;
localparam mod_frogger  = 2;
localparam mod_scobra   = 3;
localparam mod_tazman   = 4;
localparam mod_armorcar = 5;
localparam mod_moonwar  = 6;
localparam mod_spdcoin  = 7;
localparam mod_calipso  = 8;
localparam mod_darkplnt = 9;
localparam mod_anteater = 10;
localparam mod_losttomb = 11;
localparam mod_theend   = 12;
localparam mod_mars     = 13;
localparam mod_stratgyx = 14;
localparam mod_turtles  = 15;
localparam mod_minefld  = 16;
localparam mod_rescue   = 17;
localparam mod_mimonkey = 18;
localparam mod_cavelon  = 19;


reg       landscape;
reg       has_spinner;
reg       fourfire;
reg       galaxian_video;
reg [7:0] hwsel;
reg [7:0] input0;
reg [7:0] input1;
reg [7:0] input2;
reg [7:0] input3;
always @(*) begin
	has_spinner = 0;
	fourfire = 0;
	landscape = 0;
	galaxian_video = 0;
	hwsel  = 0;
	input0 = ~{ m_coin, 1'b0, m_left, m_right, m_fire_a, 1'b0, m_fire_b, m_up };
	input1 = ~{ m_start1, m_start2, m_left, m_right, m_fire_a, m_fire_b, 2'b00 };
	input2 = ~{ 1'b0, m_down, 1'b0, m_up, 3'b000, m_down };
	input3 = 8'hFF;

	case (mod)
		mod_frogger:
			begin
				hwsel = 1;
			end
		mod_scobra:
			begin
				hwsel = 2;
			end
		mod_tazman:
			begin
				hwsel = 2;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, m_fire_a, m_fire_b };
				input1 = 8'hFF;
				input2 = ~{ 1'b0, m_start2, 2'b00, 3'b000, m_start1 };
			end
		mod_armorcar:
			begin
				hwsel = 2;
			end
		mod_moonwar:
			begin
				hwsel = 2;
				has_spinner = 1;
				input0 = ~{ m_coin, 1'b0, 1'b0, moon_dial_dir, moon_dial[4:1] };
				input1 = ~{ m_fire_a, m_fire_b, m_fire_c, m_fire_d, m_start2, m_start1, 2'b00 };
				input2 = 8'hFF;
			end
		mod_spdcoin:
			begin
				hwsel = 2;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_start2, 1'b0, m_start1, 1'b0 };
				input1 = 8'hFF;
				input2 = 8'hFF;
			end
		mod_calipso:
			begin
				hwsel = 3;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, 1'b0, m_start2 | m_fire_a };
				input1 = ~{ 1'b0, 1'b0, m_left, m_right, m_down, m_up, 1'b0, 1'b0 };
				input2 = ~{ 5'b00000, 2'b00, m_fire_a | m_start1 };
			end
		mod_darkplnt:
			begin
				hwsel = 4;
				landscape = 1;
				has_spinner = 1;
				input0 = ~{ m_coin, 1'b0, 3'b000, m_start2 | m_fire_b, m_start1 | m_fire_a, m_fire_c };
				input1 = { darkplnt_dial, 2'b11 };
				input2 = 8'hFF;
			end
		mod_anteater:
			begin
				hwsel = 6;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, 1'b0, m_fire_a };
				input1 = ~{ 1'b0, m_fire_a, m_left, m_right, m_up, m_down, 2'b00 };
				input2 = ~{ 1'b0, m_start2, 2'b00, 3'b000, m_start1 };
			end
		mod_losttomb:
			begin
				hwsel = 7;
				fourfire = 1;
				input0 = status[7] ?
						 ~{ m_coin, 1'b0, m_left1, m_right1, m_down1, m_up1, m_start1, m_start2 }:
						 ~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, m_start1, m_start2 };
				input1 = status[7] ?
				         ~{ 1'b0, m_fire_e,          m_left2, m_right2, m_down2, m_up2, 2'b00 }:
						 status[6] ?
				         ~{ 1'b0, m_fire_e|m_fire_a, m_left,   m_right,  m_down,   m_up,     2'b00 }:
				         ~{ 1'b0, m_fire_e,          m_fire_d, m_fire_a, m_fire_b, m_fire_c, 2'b00 };
				input2 = 8'hFF;
			end
		mod_theend:
			begin
				galaxian_video = 1;
			end
		mod_mars:
			begin
				hwsel = 10;
				fourfire = 1;
				if(status[6]) begin
					input0 = ~{ m_coin, 1'b0, m_left, m_right, m_left, m_right, 1'b0, m_up };
					input1 = ~{ m_start1, m_start2, m_left, m_right, m_left, m_right, 2'b00 };
					input2 = ~{ m_up, m_down, m_down, m_up, 3'b000, m_down };
					input3 = ~{ m_up, 1'b0, m_down, 5'b00000 };
				end
				else if (status[7]) begin
					input0 = ~{ m_coin, 1'b0, m_left1, m_right1, m_left2, m_right2, 1'b0, m_up1 };
					input1 = ~{ m_start1, m_start2, m_left1, m_right1, m_left2, m_right2, 2'b00 };
					input2 = ~{ m_up2, m_down1, m_down2, m_up1, 3'b000, m_down1 };
					input3 = ~{ m_up2, 1'b0, m_down2, 5'b00000 };
				end
				else begin
					input0 = ~{ m_coin, 1'b0, m_left, m_right, m_fire_d, m_fire_a, 1'b0, m_up };
					input1 = ~{ m_start1, m_start2, m_left, m_right, m_fire_d, m_fire_a, 2'b00 };
					input2 = ~{ m_fire_c, m_down, m_fire_b, m_up, 3'b000, m_down };
					input3 = ~{ m_fire_c, 1'b0, m_fire_b, 5'b00000 };
				end
			end
		mod_stratgyx:
			begin
				hwsel = 5;
				landscape = 1;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_fire_a, 1'b0, m_fire_b, m_up };
				input1 = ~{ m_start1, m_start2, m_left, m_right, m_fire_a, m_fire_b, 2'b00 };
				input2 = ~{ m_fire_c, m_down, m_fire_c, m_up, 3'b000, m_down };
			end
		mod_turtles:
			begin
				hwsel = 11;
				input0 = ~{ m_coin, 1'b0, m_left, m_right, m_fire_a, 2'b00, m_up };
				input1 = ~{ m_start1, m_start2, m_left, m_right, m_fire_a, 3'b000 };
				input2 = ~{ 1'b0, m_down, 1'b0, m_up, 3'b000, m_down };
			end
		mod_minefld:
			begin
				hwsel = 8;
				fourfire = 1;
				input0 = status[7] ? ~{ m_coin, 1'b0, m_left1, m_right1, m_down1, m_up1, 1'b0, m_start1 } :
						~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, 1'b0, m_start1 };
				input1 = status[7] ? ~{ 2'b00, m_left2, m_right2, m_down2, m_up2, 2'b00 } :
						status[6] ? ~{ 2'b00, m_left, m_right, m_down, m_up, 2'b00 } : 
						~{ 2'b00, m_fire_d, m_fire_a, m_fire_b, m_fire_c, 2'b00 };
				input2 = ~{ 1'b0, m_start2, 2'b00, 3'b000, m_start1 };
			end
		mod_rescue:
			begin
				hwsel = 9;
				fourfire = 1;
				input0 = status[7] ? ~{ m_coin, 1'b0, m_left1, m_right1, m_down1, m_up1, 1'b0, m_start1 } :
						~{ m_coin, 1'b0, m_left, m_right, m_down, m_up, 1'b0, m_start1 };
				input1 = status[7] ? ~{ 2'b00, m_left2, m_right2, m_down2, m_up2, 2'b00 } :
						status[6] ? ~{ 2'b00, m_left, m_right, m_down, m_up, 2'b00 } : 
						~{ 2'b00, m_fire_d, m_fire_a, m_fire_b, m_fire_c, 2'b00 };
				input2 = ~{ 1'b0, m_start2, 2'b00, 3'b000, m_start1 };
			end
		mod_mimonkey:
			begin
				hwsel = 12;
			end
		mod_cavelon:
			begin
				hwsel = 13;
			end
		default:;
	endcase
end
wire [7:0] pa = sw[0] & input0;
wire [7:0] pb = sw[1] & input1;
wire [7:0] pc = sw[2] & input2;
wire [7:0] pd = sw[3] & input3;
assign observation = {landscape, has_spinner, fourfire, galaxian_video, hwsel,
input0, input1, input2, input3, pa, pb, pc, pd};
endmodule
