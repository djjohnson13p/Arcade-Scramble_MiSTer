`timescale 1ns/1ps
module tb;
reg [31:0] joy1=0, joy2=0, status=0;
reg [7:0] mod=0, sw0=255, sw1=253, sw2=243, sw3=255;
reg [4:0] moon_dial=0;
reg [5:0] darkplnt_dial=0;
reg moon_dial_dir=0;
wire [75:0] nobs, oobs;
decode_new n(joy1,joy2,status,mod,sw0,sw1,sw2,sw3,moon_dial,darkplnt_dial,moon_dial_dir,nobs);
decode_old o(joy1,joy2,status,mod,sw0,sw1,sw2,sw3,moon_dial,darkplnt_dial,moon_dial_dir,oobs);
integer vec, phase, st, mm, dip, random_case;
integer target_raw=0, target_dip=0, regression=0, random_regression=0, invalid_regression=0;
integer rngseed=32'h45142026;
reg [7:0] ref0, ref1, refsw1, refsw2;

function [7:0] ref_low0(input [31:0] buttons);
begin
 ref_low0=0;
 if(buttons[10]) ref_low0=ref_low0 | 8'h80; // Coin1
 if(buttons[8]) ref_low0=ref_low0 | 8'h02;  // Start1, also m_fire_e alias
 if(buttons[9]) ref_low0=ref_low0 | 8'h01;  // Start2
 if(buttons[3]) ref_low0=ref_low0 | 8'h04;  // Up
 if(buttons[2]) ref_low0=ref_low0 | 8'h08;  // Down
 if(buttons[0]) ref_low0=ref_low0 | 8'h10;  // Right
 if(buttons[1]) ref_low0=ref_low0 | 8'h20;  // Left
end
endfunction
function [7:0] ref_low1(input [31:0] buttons);
begin
 ref_low1=0;
 if(buttons[4]) ref_low1=ref_low1 | 8'h40; // Zap
 if(buttons[5]) ref_low1=ref_low1 | 8'h08; // Hold
end
endfunction

task transport(input integer p, input integer v);
begin
 case(p)
  0: begin joy1=v; joy2=0; end
  1: begin joy1=0; joy2=32'hfffff000 | v; end
  2: begin joy1=32'ha5a5a000 | (v & 12'h555); joy2=32'h5a5a5000 | (v & 12'haaa); end
  3: begin joy1=32'hfffff000 | v; joy2=32'h55555000 | v; end
 endcase
end
endtask

initial begin
 mod=20;
 // Exhaust all 12 reachable lower joystick bits: directions, A/B/C/D,
 // Start1/E alias, Start2, Coin and Pause, across four controller transports.
 // This includes every direction/diagonal plus simultaneous Hold and Zap,
 // opposite directions, unused C/D and all individual start/coin/pause states.
 for(phase=0;phase<4;phase=phase+1) begin
  status=phase << 6;
  for(vec=0;vec<4096;vec=vec+1) begin
   transport(phase,vec); moon_dial=vec; darkplnt_dial=vec >> 5; moon_dial_dir=vec >> 11;
   ref0=~ref_low0(joy1|joy2); ref1=~ref_low1(joy1|joy2);
   #1;
   if({n.hwsel,n.landscape,n.has_spinner,n.fourfire,n.galaxian_video} !== {8'd2,4'b0}
      || n.input0 !== ref0 || n.input1 !== ref1 || n.input2 !== 8'hff || n.input3 !== 8'hff) begin
    $display("FAIL_TARGET_RAW phase=%0d vec=%h got=%h,%h,%h,%h expected=%h,%h,ff,ff",phase,vec,n.input0,n.input1,n.input2,n.input3,ref0,ref1); $fatal(1);
   end
   target_raw=target_raw+1;
   // Every Lives/Coinage/Demo combination; non-DIP bits stay released high.
   for(dip=0;dip<32;dip=dip+1) begin
    refsw1=8'hfc | (dip & 3);
    refsw2=8'hf1 | ((dip >> 2 & 3) << 1) | ((dip >> 4 & 1) << 3);
    sw0=8'hff; sw1=refsw1; sw2=refsw2; sw3=8'hff;
    #1;
    if(n.pa !== ref0 || n.pb !== (ref1 & refsw1) || n.pc !== refsw2 || n.pd !== 8'hff) begin
     $display("FAIL_TARGET_DIP phase=%0d vec=%h dip=%h",phase,vec,dip); $fatal(1);
    end
    target_dip=target_dip+1;
   end
  end
 end
 // Compare production old/new logic for every existing mode, every lower
 // joystick combination, every relevant status6/7 state, and three controller
 // transports. Dial values and switch bytes cycle through their full ranges.
 for(mm=0;mm<20;mm=mm+1) begin
  mod=mm;
  for(st=0;st<4;st=st+1) begin
   status=st << 6;
   for(phase=0;phase<3;phase=phase+1) begin
    for(vec=0;vec<4096;vec=vec+1) begin
     transport(phase,vec);
     moon_dial=vec; darkplnt_dial=vec >> 5; moon_dial_dir=vec >> 11;
     sw0=vec; sw1=vec*37; sw2=vec*73; sw3=vec*109;
     #1;
     if(nobs !== oobs) begin
      $display("FAIL_EXISTING mode=%0d st=%0d phase=%0d vec=%h new=%h old=%h",mm,st,phase,vec,nobs,oobs); $fatal(1);
     end
     regression=regression+1;
    end
   end
  end
 end
 // Independently varied full 32-bit controllers cover joint-port states that
 // the exhaustive logical transports intentionally coalesce.
 for(mm=0;mm<20;mm=mm+1) begin
  mod=mm;
  for(random_case=0;random_case<2048;random_case=random_case+1) begin
   joy1=$random(rngseed); joy2=$random(rngseed); status=$random(rngseed);
   moon_dial=$random(rngseed); darkplnt_dial=$random(rngseed); moon_dial_dir=$random(rngseed);
   sw0=$random(rngseed); sw1=$random(rngseed); sw2=$random(rngseed); sw3=$random(rngseed);
   #1;
   if(nobs !== oobs) begin $display("FAIL_RANDOM mode=%0d case=%0d",mm,random_case); $fatal(1); end
   random_regression=random_regression+1;
  end
 end
 // Every unassigned mode byte must retain the old default behavior.
 for(mm=21;mm<256;mm=mm+1) begin
  mod=mm;
  for(random_case=0;random_case<16;random_case=random_case+1) begin
   joy1=$random(rngseed); joy2=$random(rngseed); status=$random(rngseed);
   moon_dial=$random(rngseed); darkplnt_dial=$random(rngseed); moon_dial_dir=$random(rngseed);
   sw0=$random(rngseed); sw1=$random(rngseed); sw2=$random(rngseed); sw3=$random(rngseed);
   #1;
   if(nobs !== oobs) begin $display("FAIL_DEFAULT mode=%0d case=%0d",mm,random_case); $fatal(1); end
   invalid_regression=invalid_regression+1;
  end
 end
 $display("PASS target_raw=%0d target_dip=%0d existing_exhaustive_transports=%0d existing_random_joint_ports=%0d invalid_mode_vectors=%0d",target_raw,target_dip,regression,random_regression,invalid_regression);
 $finish;
end
endmodule
