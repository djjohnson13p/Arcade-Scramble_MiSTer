"""One focused contract suite against extracted production SystemVerilog."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
CORE = ROOT / "core-lab/cores/Arcade-Scramble_MiSTer"
PIN = "dea71c93615030583b23362226708f67d2294458"
EXPECTED = "bb3eaec714b73666e3d4851b06cef854058d081e75494f216fd3d4bbca21227f"
WRAPPER = ROOT / "core-lab/research/triple-play-feasibility-20261024/mapper-probe/run_icarus.py"
MRA = CORE / "releases/Agent Super Bond (Super Cobra conversion, not encrypted).mra"
REFERENCE = ROOT / "core-lab/research/superbond-feasibility-20261024/stock-repro-r1/source-issue-45.mra"
ZIP = ROOT / "core-lab/rom-inputs/superbond/superbona.zip"
digest = lambda data: hashlib.sha256(data).hexdigest()
current = (CORE / "Arcade-Scramble.sv").read_bytes()
assert digest(current) == EXPECTED, "Candidate changed since root bound the test"
old = subprocess.run(["git", "-C", str(CORE), "show", f"{PIN}:Arcade-Scramble.sv"], check=True, capture_output=True).stdout


def extract(data, name):
    source = data.decode("utf-8").replace("\r\n", "\n")
    localparams = source[source.index("localparam mod_scramble"):source.index("reg [7:0] mod = 0;")]
    controls = source[source.index("wire m_up1"):source.index("// PAUSE SYSTEM")]
    declarations = re.search(r"reg\s+landscape;[\s\S]*?reg\s+\[7:0\]\s+input3;", source).group()
    start = source.index("always @(*) begin\n\thas_spinner")
    decode = source[start:source.index("wire [4:0] moon_dial;", start)].strip()
    ppi = dict(re.findall(r"\.I_P([ABCD])\(([^)]+)\)", source))
    assert set(ppi) == set("ABCD")
    assignments = "\n".join(f"wire [7:0] p{x.lower()} = {ppi[x]};" for x in "ABCD")
    body = f"""module {name} (
input [31:0] joy1, joy2, status,
input [7:0] mod, sw0, sw1, sw2, sw3,
input [4:0] moon_dial,
input [5:0] darkplnt_dial,
input moon_dial_dir,
output [75:0] observation
);
wire [31:0] joy = joy1 | joy2;
wire [7:0] sw[8];
assign sw[0]=sw0; assign sw[1]=sw1; assign sw[2]=sw2; assign sw[3]=sw3;
{controls}
{localparams}
{declarations}
{decode}
{assignments}
assign observation = {{landscape, has_spinner, fourfire, galaxian_video, hwsel,
input0, input1, input2, input3, pa, pb, pc, pd}};
endmodule
"""
    return body, {"localparams_sha256": digest(localparams.encode()), "control_wires_sha256": digest(controls.encode()), "decode_sha256": digest(decode.encode()), "ppi_expressions": ppi}


new_module, new_parts = extract(current, "decode_new")
old_module, old_parts = extract(old, "decode_old")
assert new_parts["control_wires_sha256"] == old_parts["control_wires_sha256"]
assert new_parts["ppi_expressions"] == old_parts["ppi_expressions"]
(OUT / "extracted.sv").write_text(new_module + "\n" + old_module, encoding="utf-8")

# Expected masks are independent MAME port-bit definitions, not a copied RTL
# concatenation: Coin1 80; Start1 02; Start2 01; U/D/R/L 04/08/10/20;
# Zap 40 and Hold 08 on IN1. Fire E is physically the same joy[8] as Start1.
tb = r"""`timescale 1ns/1ps
module tb;
reg [31:0] joy1=0, joy2=0, status=0;
reg [7:0] mod=0, sw0=255, sw1=253, sw2=243, sw3=255;
reg [4:0] moon_dial=0;
reg [5:0] darkplnt_dial=0;
reg moon_dial_dir=0;
wire [75:0] nobs, oobs;
decode_new n(joy1,joy2,status,mod,sw0,sw1,sw2,sw3,moon_dial,darkplnt_dial,moon_dial_dir,nobs);
decode_old o(joy1,joy2,status,mod,sw0,sw1,sw2,sw3,moon_dial,darkplnt_dial,moon_dial_dir,oobs);
integer vec, phase, st, mm, dip, random_case;
integer target_raw=0, target_dip=0, regression=0, random_regression=0, invalid_regression=0;
integer rngseed=32'h45142026;
reg [7:0] ref0, ref1, refsw1, refsw2;

function [7:0] ref_low0(input [31:0] buttons);
begin
 ref_low0=0;
 if(buttons[10]) ref_low0=ref_low0 | 8'h80; // Coin1
 if(buttons[8]) ref_low0=ref_low0 | 8'h02;  // Start1, also m_fire_e alias
 if(buttons[9]) ref_low0=ref_low0 | 8'h01;  // Start2
 if(buttons[3]) ref_low0=ref_low0 | 8'h04;  // Up
 if(buttons[2]) ref_low0=ref_low0 | 8'h08;  // Down
 if(buttons[0]) ref_low0=ref_low0 | 8'h10;  // Right
 if(buttons[1]) ref_low0=ref_low0 | 8'h20;  // Left
end
endfunction
function [7:0] ref_low1(input [31:0] buttons);
begin
 ref_low1=0;
 if(buttons[4]) ref_low1=ref_low1 | 8'h40; // Zap
 if(buttons[5]) ref_low1=ref_low1 | 8'h08; // Hold
end
endfunction

task transport(input integer p, input integer v);
begin
 case(p)
  0: begin joy1=v; joy2=0; end
  1: begin joy1=0; joy2=32'hfffff000 | v; end
  2: begin joy1=32'ha5a5a000 | (v & 12'h555); joy2=32'h5a5a5000 | (v & 12'haaa); end
  3: begin joy1=32'hfffff000 | v; joy2=32'h55555000 | v; end
 endcase
end
endtask

initial begin
 mod=20;
 // Exhaust all 12 reachable lower joystick bits: directions, A/B/C/D,
 // Start1/E alias, Start2, Coin and Pause, across four controller transports.
 // This includes every direction/diagonal plus simultaneous Hold and Zap,
 // opposite directions, unused C/D and all individual start/coin/pause states.
 for(phase=0;phase<4;phase=phase+1) begin
  status=phase << 6;
  for(vec=0;vec<4096;vec=vec+1) begin
   transport(phase,vec); moon_dial=vec; darkplnt_dial=vec >> 5; moon_dial_dir=vec >> 11;
   ref0=~ref_low0(joy1|joy2); ref1=~ref_low1(joy1|joy2);
   #1;
   if({n.hwsel,n.landscape,n.has_spinner,n.fourfire,n.galaxian_video} !== {8'd2,4'b0}
      || n.input0 !== ref0 || n.input1 !== ref1 || n.input2 !== 8'hff || n.input3 !== 8'hff) begin
    $display("FAIL_TARGET_RAW phase=%0d vec=%h got=%h,%h,%h,%h expected=%h,%h,ff,ff",phase,vec,n.input0,n.input1,n.input2,n.input3,ref0,ref1); $fatal(1);
   end
   target_raw=target_raw+1;
   // Every Lives/Coinage/Demo combination; non-DIP bits stay released high.
   for(dip=0;dip<32;dip=dip+1) begin
    refsw1=8'hfc | (dip & 3);
    refsw2=8'hf1 | ((dip >> 2 & 3) << 1) | ((dip >> 4 & 1) << 3);
    sw0=8'hff; sw1=refsw1; sw2=refsw2; sw3=8'hff;
    #1;
    if(n.pa !== ref0 || n.pb !== (ref1 & refsw1) || n.pc !== refsw2 || n.pd !== 8'hff) begin
     $display("FAIL_TARGET_DIP phase=%0d vec=%h dip=%h",phase,vec,dip); $fatal(1);
    end
    target_dip=target_dip+1;
   end
  end
 end
 // Compare production old/new logic for every existing mode, every lower
 // joystick combination, every relevant status6/7 state, and three controller
 // transports. Dial values and switch bytes cycle through their full ranges.
 for(mm=0;mm<20;mm=mm+1) begin
  mod=mm;
  for(st=0;st<4;st=st+1) begin
   status=st << 6;
   for(phase=0;phase<3;phase=phase+1) begin
    for(vec=0;vec<4096;vec=vec+1) begin
     transport(phase,vec);
     moon_dial=vec; darkplnt_dial=vec >> 5; moon_dial_dir=vec >> 11;
     sw0=vec; sw1=vec*37; sw2=vec*73; sw3=vec*109;
     #1;
     if(nobs !== oobs) begin
      $display("FAIL_EXISTING mode=%0d st=%0d phase=%0d vec=%h new=%h old=%h",mm,st,phase,vec,nobs,oobs); $fatal(1);
     end
     regression=regression+1;
    end
   end
  end
 end
 // Independently varied full 32-bit controllers cover joint-port states that
 // the exhaustive logical transports intentionally coalesce.
 for(mm=0;mm<20;mm=mm+1) begin
  mod=mm;
  for(random_case=0;random_case<2048;random_case=random_case+1) begin
   joy1=$random(rngseed); joy2=$random(rngseed); status=$random(rngseed);
   moon_dial=$random(rngseed); darkplnt_dial=$random(rngseed); moon_dial_dir=$random(rngseed);
   sw0=$random(rngseed); sw1=$random(rngseed); sw2=$random(rngseed); sw3=$random(rngseed);
   #1;
   if(nobs !== oobs) begin $display("FAIL_RANDOM mode=%0d case=%0d",mm,random_case); $fatal(1); end
   random_regression=random_regression+1;
  end
 end
 // Every unassigned mode byte must retain the old default behavior.
 for(mm=21;mm<256;mm=mm+1) begin
  mod=mm;
  for(random_case=0;random_case<16;random_case=random_case+1) begin
   joy1=$random(rngseed); joy2=$random(rngseed); status=$random(rngseed);
   moon_dial=$random(rngseed); darkplnt_dial=$random(rngseed); moon_dial_dir=$random(rngseed);
   sw0=$random(rngseed); sw1=$random(rngseed); sw2=$random(rngseed); sw3=$random(rngseed);
   #1;
   if(nobs !== oobs) begin $display("FAIL_DEFAULT mode=%0d case=%0d",mm,random_case); $fatal(1); end
   invalid_regression=invalid_regression+1;
  end
 end
 $display("PASS target_raw=%0d target_dip=%0d existing_exhaustive_transports=%0d existing_random_joint_ports=%0d invalid_mode_vectors=%0d",target_raw,target_dip,regression,random_regression,invalid_regression);
 $finish;
end
endmodule
"""
(OUT / "tb.sv").write_text(tb, encoding="utf-8")


def payload(root):
    rom = root.find("rom[@index='0']")
    assert rom is not None
    signature = [(tuple(sorted(part.attrib.items())), (part.text or "").strip()) for part in rom]
    assembled = bytearray()
    with zipfile.ZipFile(ZIP) as archive:
        for part in rom:
            assert part.tag == "part" and "name" in part.attrib
            member = archive.getinfo(part.attrib["name"])
            assert f"{member.CRC:08x}" == part.attrib["crc"].lower()
            assembled.extend(archive.read(member) * int(part.attrib.get("repeat", "1"), 0))
    return bytes(assembled), signature


mra = ET.parse(MRA).getroot()
reference = ET.parse(REFERENCE).getroot()
assert mra.findtext("setname") == "superbona" and mra.findtext("parent") == "superbon"
assert mra.findtext("rbf") == "scramble"
assert mra.findtext("players") == "2 (alternating)"
assert mra.findtext("joystick") == "8-way" and mra.findtext("num_buttons") == "2"
assert mra.find("buttons").attrib == {"default": "A,B,Start,Select,R,L", "names": "Zap,Hold,-,-,Start 1P,Start 2P,Coin,Pause"}
assert bytes.fromhex(mra.findtext("rom[@index='1']/part")) == b"\x14"
switches = mra.find("switches")
assert switches.attrib["default"] == "FF,FD,F3"
assert [dip.attrib for dip in switches] == [
    {"bits": "8,9", "ids": "Invulnerable,3,5,Free Play", "name": "Lives"},
    {"bits": "17,18", "ids": "1c/2cr,1c/1cr,1c/3cr,1c/4cr", "name": "Coinage"},
    {"bits": "19", "ids": "On,Off", "name": "Demo Sounds"},
]
assert mra.find("nvram") is None
assert "provisional" in mra.findtext("remark") and "not been dumped" in mra.findtext("remark")
new_payload, new_signature = payload(mra)
old_payload, old_signature = payload(reference)
assert new_signature == old_signature and new_payload == old_payload
assert len(new_payload) == 57376 and hashlib.md5(new_payload).hexdigest() == "f65f589945276dc75b001d59182aba4d"
assert mra.find("rom[@index='0']").attrib == reference.find("rom[@index='0']").attrib

commands = [
    [sys.executable, "-B", "-Xutf8", str(WRAPPER), "iverilog", "-g2012", "-s", "tb", "-o", "contract.vvp", "extracted.sv", "tb.sv"],
    [sys.executable, "-B", "-Xutf8", str(WRAPPER), "vvp", "contract.vvp"],
]
results = []
for command, timeout in zip(commands, [30, 45]):
    start = time.monotonic()
    result = subprocess.run(command, cwd=OUT, capture_output=True, text=True, timeout=timeout)
    results.append({"command": command, "cwd": str(OUT), "exit_code": result.returncode, "elapsed_seconds": round(time.monotonic()-start, 3), "stdout": result.stdout, "stderr": result.stderr})
    print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, file=sys.stderr, end="")
    if result.returncode:
        (OUT / "result.json").write_text(json.dumps({"decision": "FAIL", "commands": results}, indent=2), encoding="utf-8")
        raise SystemExit(result.returncode)
assert "PASS target_raw=16384 target_dip=524288 existing_exhaustive_transports=983040 existing_random_joint_ports=40960 invalid_mode_vectors=3760" in results[-1]["stdout"]
assert digest((CORE / "Arcade-Scramble.sv").read_bytes()) == EXPECTED
report = {
    "decision": "PASS_LOCAL_INPUT_AND_MRA_CONTRACT",
    "candidate_source_sha256": EXPECTED,
    "old_pin": PIN,
    "old_source_sha256": digest(old),
    "mra_sha256": digest(MRA.read_bytes()),
    "zip_sha256": digest(ZIP.read_bytes()),
    "extracts": {"candidate": new_parts, "old": old_parts},
    "reference": "MAME b7c0bfd16c9b8fe451c7e3d9cf7642c857642c44 galaxian.cpp losttomb inputs + superbon overrides, reviewed in mapping-plan-r1.json",
    "controls": {"logical_bits_exhausted": 12, "target_transports": 4, "target_raw": 16384, "target_all_32_dip_combinations": 524288, "old_modes": list(range(20)), "old_exhaustive_transports": 983040, "old_random_independent_ports": 40960, "invalid_mode_bytes": "21..255", "invalid_mode_vectors": 3760, "fire_e": "joy[8] also Start1: verified only Start1 effect, no Hold/Zap alias"},
    "mra": {"mode": "14", "defaults": "FF,FD,F3", "labels": "Zap,Hold,-,-,Start 1P,Start 2P,Coin,Pause", "payload_composition_unchanged": True, "payload_bytes": len(new_payload), "payload_md5": hashlib.md5(new_payload).hexdigest(), "palette_limitation_declared": True},
    "commands": results,
    "artifacts": {name: digest((OUT/name).read_bytes()) for name in ["verify.py", "extracted.sv", "tb.sv", "contract.vvp"]},
    "limits": "Extracted production input logic plus actual DIP-AND expressions only; no timing, full-core elaboration, audio, graphics, gameplay, electrical or hardware acceptance is claimed. Joint 64-bit controller space is sampled after exhaustive logical transports.",
}
(OUT / "result.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print("PASS MRA controls, DIP masks/defaults, mode14, unchanged ROM composition and MD5; candidate source hash stable")
