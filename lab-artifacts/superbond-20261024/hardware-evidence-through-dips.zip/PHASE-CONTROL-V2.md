# Phase helper v2: keyboard lifecycle correction

Use `phase_control_v2.py` with the same DEVICE-READY/action schemas and reviewed
hash CLI arguments described in PHASE-CONTROL.md. The original executed helper,
note and stopped journal remain unchanged. The v1 boot attempt stopped before
acquisition/load/input because no misterclaw keyboard existed; preserved hashes
and Menu/User remained verified. This was a helper preflight limitation, not a
candidate boot or control result.

Canonical input source creates misterclaw lazily, while core loading closes
the keyboard. V2 therefore removes the keyboard-existence check before load.
Capture-only boot phases and the separate finish-to-Menu phase require no
keyboard and emit no neutral input.

For a phase containing game input, v2 first acquires its epoch and completes
any one reviewed load. Under fresh exact alias/epoch and input-capability
checks it emits exactly one fixed LeftShift1ms initialization, with a fresh ID
and pre-dispatch journal entry. It requires a matching terminal completed reply,
then verifies exactly one misterclaw USB4711:0815/version1 keyboard in /proc and
rechecks ownership before allowing any game input. A missing/wrong keyboard,
uncertain initializer or changed ownership stops all game inputs. No replay.

The seven conventional map words have no KEY_LEFTSHIFT42 binding. Root also
reviewed the core's absence of a PS/2 keyboard decoder. This fixed neutral
initializer cannot drive a mapped game action. It is internal, at most once
per input phase; the action JSON remains restricted to the existing nine keys.
Action bounds, one-shot journal, same-epoch independent release/User cleanup,
preservation checks and leave-game-running behavior are unchanged. No daemon,
transport, map, core, RBF or timing change is part of v2.
