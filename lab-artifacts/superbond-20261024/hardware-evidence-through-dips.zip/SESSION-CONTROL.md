# Persistent reviewed hardware session

`session_control.py` reuses pinned v2 SHA
`419ac74c5546bcd24d5da1168b7034bd108dc6ea588668db5e13e4a30c9195c3`.
Default validation stays local. A root-reviewed script and DEVICE-READY digest,
plus a unique exclusive session journal, authorize interactive stdin commands;
no per-command action file/hash is needed. One SSH/SFTP connection remains open.
Device hashes/membership are verified once at start and again on close.

After root review, use pinned Python with `--execute --ready-sha256 HASH
--script-sha256 HASH --session-id UNIQUE_LOWERCASE_NAME`, then send one JSON
object per stdin line:

```json
{"op":"load","alias":"SB45F001"}
{"op":"input","keys":["5"],"duration_ms":60}
{"op":"input","keys":["up","leftalt"],"duration_ms":150}
{"op":"screenshot","label":"after-hold","settle_ms":0}
{"op":"finish"}
{"op":"close"}
```

Load accepts only the seven known aliases and starts only from idle User on
Menu/a known test alias. Input uses v2's nine keys, at most four unique members,
no opposite directions, timed1–5000ms. Screenshot settle is optional0–5000ms;
labels must be unique lowercase alphanumeric/hyphen names. Finish explicitly
loads Menu from a known test alias. Close/EOF leaves the current game running.

Each command has fresh identity/epoch checks, a pre-dispatch journal and strict
terminal input/load IDs. Independent same-epoch release and User handoff occur
after each command. V2 neutral keyboard initialization precedes the first input
after a load/alias change or more than90s input idle. Input-free commands do not
initialize a keyboard. Any uncertain action/cleanup terminates the session;
there is no retry or automatic gameplay PASS. Each command retains v2's
cooperative180s action deadline and finite transport timeouts. Journals and
screenshots remain under `session-journals/`; session IDs cannot be reused.
