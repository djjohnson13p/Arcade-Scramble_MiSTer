"""One reviewed hardware phase. Default is local-only; no transport is imported."""
import argparse
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import struct
import sys
import time
import uuid

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
READY=OUT/'DEVICE-READY.json'
MENU='/media/fat/menu.rbf'
RBF='/media/fat/_Arcade/cores/SB45F001.rbf'
ALIASES=tuple('SB45F00'+str(i) for i in range(1,6))+('SB45R001','SB45R002')
KEYS={'up','down','left','right','leftctrl','leftalt','1','2','5'}
HELPERS={ROOT/'core-lab/scripts/run_megacd_payload_pair.py':'fc9837d0cce23f6bf468967d39b9c21055e52f54e19210e5619db5d8c763c9cd',
    Path('C:/Users/djjoh/MiSTer-Rebuild/Tools/mister_control.py'):'78f46677ece7b9582dc86e3d53bf6c64bfed8c7f48d3e8ea16b3c15bcb998789'}
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def must(ok,message):
    if not ok:raise RuntimeError(message)

def digest(value):must(isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value),'Invalid SHA256')

def remote(path):must(isinstance(path,str) and path.startswith('/media/fat/') and not any(c in path for c in ('\n','\r','\\')) and '..' not in Path(path).parts,'Invalid remote path')

def leg(alias):return {'mgl':f'/media/fat/_Arcade/_CoreLab/{alias}.mra','rbf':RBF}

def save(s):
    Path(s['_journal']).write_text(json.dumps(s,indent=2,sort_keys=True)+'\n',encoding='utf-8')

def slim(state):return {'game':state['game'],'control':{key:state['control'].get(key) for key in ('success','mode','epoch','active_input','active_action','cleanup_error','transition_in_progress')}}

def menu_state(a,state,mode,epoch=None):
    normalized={'game':dict(state['game']),'control':state['control']}
    if normalized['game'].get('core_path')=='menu.rbf':normalized['game']['core_path']=MENU
    a.menu(normalized,mode,epoch)

def identity(a,state,alias,mode,epoch=None):
    must(a.idle(state['control'],mode,epoch),'Control is not idle in the expected mode/epoch')
    if alias=='MENU':menu_state(a,state,mode,epoch)
    else:
        must(state['game'].get('core_path')==RBF and state['game'].get('game_path')==leg(alias)['mgl'] and not state['game'].get('error'),'Unexpected game identity; no load or input permitted')

def guarded(a,c,s,alias):
    must(time.monotonic()<s['_deadline'],'Cooperative phase action deadline reached')
    state=a.state(c);identity(a,state,alias,'assistant',s['epoch']);return state

def verify_local(action_path=None):
    raw_ready=READY.read_bytes();ready=json.loads(raw_ready);ready['_loaded_sha256']=sha(raw_ready)
    must(ready['schema']=='SB45-DEVICE-READY-1','Wrong ready schema')
    must(ready['source_sha256']=='bb3eaec714b73666e3d4851b06cef854058d081e75494f216fd3d4bbca21227f','Wrong reviewed candidate source')
    rbf=ready['candidate_rbf'];must(rbf['remote']==RBF and type(rbf['bytes']) is int and rbf['bytes']>0,'Wrong candidate RBF binding');digest(rbf['sha256'])
    must(set(ready['fixtures'])==set(ALIASES),'Ready must bind exactly seven known aliases')
    for alias,fixture in ready['fixtures'].items():
        must(set(fixture)=={'mra','map'},'Each fixture binds exactly its MRA and map')
        for kind,name,path in (('mra',alias+'.mra',leg(alias)['mgl']),('map',alias+'_input_4711_0815_v3.map',f'/media/fat/config/inputs/{alias}_input_4711_0815_v3.map')):
            item=fixture[kind];raw=(OUT/name).read_bytes()
            must(item['remote']==path and item['bytes']==len(raw) and item['sha256']==sha(raw),'Local fixture/binding changed: '+name)
        must(struct.unpack('<32I',(OUT/(alias+'_input_4711_0815_v3.map')).read_bytes())==tuple([106,105,108,103,29,56,0,0,2,3,6,0]+[0]*20),'Unexpected conventional map')
    originals=ready['protected_original_hashes'];must(bool(originals),'No protected originals')
    for path,value in originals.items():remote(path);digest(value)
    union=json.loads((OUT/'preservation-union.json').read_text())['known_original_hashes']
    must(all(originals.get(path)==value for path,value in union.items()),'Ready omits or changes preserved originals')
    members=ready['protected_membership'];must(isinstance(members,list) and members==sorted(set(members)) and set(members)<=set(originals),'Membership must be sorted, unique and hash-bound')
    for path in members:remote(path)
    timing=ready['timing_review'];digest(timing['sha256'])
    must(timing['positive_all_corner_timing'] is True and Path(timing['local_path']).is_absolute() and sha(Path(timing['local_path']).read_bytes())==timing['sha256'],'Positive timing review is missing or changed')
    for path,value in HELPERS.items():must(sha(path.read_bytes())==value,'Existing transport/helper changed: '+str(path))
    if action_path is None:return ready,None
    raw_action=Path(action_path).read_bytes();action=json.loads(raw_action);action['_loaded_sha256']=sha(raw_action)
    must(action['schema']=='SB45-PHASE-ACTION-1','Wrong action schema')
    must(re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',action['phase_id']) is not None,'Invalid phase ID')
    must(action['alias'] in ALIASES and action['expected_start'] in ('MENU',*ALIASES),'Unknown alias')
    must(type(action['load_alias']) is bool and type(action['finish_to_menu']) is bool,'Load/finish flags must be boolean')
    must(type(action['deadline_seconds']) is int and 1<=action['deadline_seconds']<=180,'Phase deadline must be 1..180 seconds')
    steps=action['actions'];must(isinstance(steps,list) and len(steps)<=16,'At most sixteen steps')
    if action['finish_to_menu']:
        must(not action['load_alias'] and action['expected_start']==action['alias'] and steps==[],'Finish is a separate no-input phase from its known test alias')
    else:must(action['load_alias'] or action['expected_start']==action['alias'],'No-load phase must already be on the selected alias')
    must(action['expected_start']!='MENU' or action['load_alias'],'A Menu phase must load its alias')
    input_ms=settle_ms=inputs=captures=0;labels=set()
    for step in steps:
        if step['kind']=='input':
            must(set(step)=={'kind','keys','duration_ms'},'Unexpected input fields')
            keys=step['keys'];duration=step['duration_ms']
            must(isinstance(keys,list) and 1<=len(keys)<=4 and len(set(keys))==len(keys) and set(keys)<=KEYS,'Unknown/duplicate keyboard keys')
            must(not {'left','right'}<=set(keys) and not {'up','down'}<=set(keys),'Opposite-direction combo is not a phase control')
            must(type(duration) is int and 1<=duration<=5000,'Input duration must be 1..5000ms')
            inputs+=1;input_ms+=duration
        elif step['kind']=='screenshot':
            must(set(step)=={'kind','label','settle_ms'},'Unexpected screenshot fields')
            must(isinstance(step['label'],str) and re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',step['label']) is not None and step['label'] not in labels,'Invalid/duplicate screenshot label')
            must(type(step['settle_ms']) is int and 0<=step['settle_ms']<=5000,'Screenshot settle must be 0..5000ms')
            labels.add(step['label']);captures+=1;settle_ms+=step['settle_ms']
        else:raise RuntimeError('Unknown phase step')
    must(inputs<=12 and captures<=8 and input_ms<=30000 and settle_ms<=30000,'Phase exceeds short action bounds')
    return ready,action

def transport_api():
    spec=importlib.util.spec_from_file_location('existing_phase_transport',ROOT/'core-lab/scripts/run_megacd_payload_pair.py')
    api=importlib.util.module_from_spec(spec);spec.loader.exec_module(api);return api

def shell(c,command):
    with c.transport.open_session(timeout=10) as channel:
        channel.settimeout(30);channel.exec_command(command)
        out=channel.makefile('rb').read(2000000).decode();error=channel.makefile_stderr('rb').read(2000).decode(errors='replace')
        must(channel.recv_exit_status()==0,'Read-only remote check failed: '+error);return out

def device_check(c,sf,ready):
    files={ready['candidate_rbf']['remote']:ready['candidate_rbf']}
    for fixture in ready['fixtures'].values():
        for item in fixture.values():files[item['remote']]=item
    expected=dict(ready['protected_original_hashes']);expected.update({path:item['sha256'] for path,item in files.items()})
    must(len(expected)<2000,'Protected set unexpectedly large')
    values={line.split(None,1)[1].strip():line.split(None,1)[0] for line in shell(c,'sha256sum -- '+' '.join(shlex.quote(path) for path in sorted(expected))).splitlines()}
    must(values==expected,'Staged or protected device hashes differ')
    for path,item in files.items():must(sf.stat(path).st_size==item['bytes'],'Staged file size changed: '+path)
    members=[]
    for path in shell(c,'find /media/fat/config /media/fat/saves -type f -print').splitlines():
        low=path.lower()
        if any(alias.lower() in low for alias in ALIASES):continue
        if low.startswith('/media/fat/config/inputs/') or low.endswith('.map') or re.search(r'scram|scrmbl|scobra|super.?cobra|superbon|super.?bond',low):members.append(path)
    must(sorted(set(members))==ready['protected_membership'],'Protected config/save/map membership changed')

def wire(c,s,payload,label):
    payload=dict(payload);payload['id']='SB45PH-'+uuid.uuid4().hex
    event={'label':label,'payload':payload,'started':time.time()};s['events'].append(event);save(s)
    reply=c.request(payload);event['reply']={key:value for key,value in reply.items() if key!='data'};save(s)
    must(reply.get('id')==payload['id'],'Request ID uncertain; do not replay');return reply

def initialize_for_inputs(a,c,s,steps):
    if not any(step['kind']=='input' for step in steps):return
    current=guarded(a,c,s,s['alias'])
    must(not s.get('neutral_initialization_attempted'),'Neutral initialization was already attempted; do not replay')
    type(c).request.__globals__['preflight_input'](current['control'],1)
    s['neutral_initialization_attempted']=True;save(s)
    reply=wire(c,s,{'mister':'input','device':'keyboard','key':'leftshift','duration_ms':1},'one-neutral-keyboard-initialization')
    must(reply.get('success') is True and reply.get('status')=='completed' and reply.get('action_id')==reply.get('id'),'Neutral initialization outcome uncertain; no game input permitted')
    guarded(a,c,s,s['alias'])
    keyboard=shell(c,'cat /proc/bus/input/devices')
    blocks=[block for block in keyboard.split('\n\n') if 'N: Name="misterclaw"' in block]
    must(len(blocks)==1 and 'Bus=0003 Vendor=4711 Product=0815 Version=0001' in blocks[0] and 'kbd' in blocks[0],'Post-initialization misterclaw keyboard identity is not verified; no game input permitted')
    guarded(a,c,s,s['alias']);s['keyboard_identity_verified']=blocks[0];save(s)

def load_once(a,c,s,source,destination):
    guarded(a,c,s,source);must(not s.get('load_attempted'),'A load was already attempted')
    s['load_attempted']=True;save(s)
    reply=wire(c,s,{'mister':'load_core','path':MENU if destination=='MENU' else leg(destination)['mgl']},'one-load-'+destination)
    must(reply.get('success') is True and reply.get('status')=='completed' and reply.get('action_id')==reply.get('id'),'Load outcome uncertain; do not replay')
    limit=min(s['_deadline'],time.monotonic()+60)
    while time.monotonic()<limit:
        state=a.state(c);must(a.idle(state['control'],'assistant',s['epoch']),'Ownership/input state changed during load')
        try:identity(a,state,destination,'assistant',s['epoch']);return
        except RuntimeError:pass
        game=state['game'];must(not game.get('error') and game.get('core_path') in ('',RBF,MENU,'menu.rbf') and game.get('game_path','') in ('',leg(s['alias'])['mgl'],leg(source)['mgl'] if source!='MENU' else ''),'Unexpected core/game during load; no further actions')
        time.sleep(1)
    raise RuntimeError('Initial load readiness observation expired; do not replay')

def cleanup(a,c,s):
    errors=[]
    for operation in ('release_all','user'):
        try:
            state=a.state(c);control=state['control']
            if s.get('epoch') and control.get('mode')=='assistant' and control.get('epoch')==s['epoch']:
                reply=wire(c,s,{'mister':'control','action':operation},'final-'+operation)
                must(reply.get('success') is True,operation+' was not acknowledged')
        except BaseException as error:errors.append(operation+': '+str(error))
    try:
        final=a.state(c);s['final_state']=slim(final)
        must(a.idle(final['control'],'user'),'Final User/idle state is not verified; ownership is never guessed')
        if s['result']=='ACTIONS_CAPTURED_FOR_HUMAN_REVIEW':identity(a,final,'MENU' if s['finish_to_menu'] else s['alias'],'user')
    except BaseException as error:errors.append('Final verification: '+str(error))
    s['cleanup_errors']=errors
    if errors:s['recovery_required']='; '.join(errors)

def execute(args,ready,action):
    for actual,reviewed,label in ((ready['_loaded_sha256'],args.ready_sha256,'ready'),(action['_loaded_sha256'],args.action_sha256,'action'),(sha(Path(__file__).read_bytes()),args.script_sha256,'script')):
        digest(reviewed);must(actual==reviewed,'Reviewed '+label+' digest mismatch')
    phase_hash=args.action_sha256;folder=OUT/'phase-journals';folder.mkdir(exist_ok=True)
    journal=folder/(phase_hash+'.json')
    s={'phase_id':action['phase_id'],'alias':action['alias'],'finish_to_menu':action['finish_to_menu'],
        'ready_sha256':args.ready_sha256,'action_sha256':phase_hash,'script_sha256':args.script_sha256,
        '_journal':str(journal),'_deadline':time.monotonic()+action['deadline_seconds'],'started':time.time(),
        'result':'STARTED_DO_NOT_REPEAT','events':[],'captures':[]}
    with journal.open('x',encoding='utf-8') as stream:json.dump(s,stream)
    capture_dir=folder/phase_hash;capture_dir.mkdir()
    try:
        a=transport_api()
        with a.device() as (c,sf):
            sf.get_channel().settimeout(30)
            try:
                identity(a,a.state(c),action['expected_start'],'user')
                device_check(c,sf,ready)
                identity(a,a.state(c),action['expected_start'],'user')
                must(time.monotonic()<s['_deadline'],'Phase deadline reached before acquisition')
                s['handoff_attempted']=True;save(s)
                handoff=wire(c,s,{'mister':'control','action':'assistant'},'one-assistant-handoff')
                if handoff.get('success') is True and handoff.get('mode')=='assistant' and handoff.get('epoch'):s['epoch']=handoff['epoch'];save(s)
                must(a.idle(handoff,'assistant'),'Assistant handoff is not idle')
                guarded(a,c,s,action['expected_start'])
                if action['load_alias']:load_once(a,c,s,action['expected_start'],action['alias'])
                initialize_for_inputs(a,c,s,action['actions'])
                for step in action['actions']:
                    current=guarded(a,c,s,action['alias'])
                    if step['kind']=='input':
                        type(c).request.__globals__['preflight_input'](current['control'],step['duration_ms'])
                        payload={'mister':'input','device':'keyboard','duration_ms':step['duration_ms']}
                        payload['key' if len(step['keys'])==1 else 'combo']=step['keys'][0] if len(step['keys'])==1 else step['keys']
                        reply=wire(c,s,payload,'timed-input')
                        must(reply.get('success') is True and reply.get('status')=='completed' and reply.get('action_id')==reply.get('id'),'Input outcome uncertain; do not replay')
                    else:
                        time.sleep(step['settle_ms']/1000);guarded(a,c,s,action['alias'])
                        event={'label':step['label'],'local_capture_id':uuid.uuid4().hex,'started':time.time()};s['captures'].append(event);save(s)
                        reply=c.request({'mister':'screenshot'});must(reply.get('success') is True,'Screenshot failed')
                        raw=base64.b64decode(reply['data'],validate=True)
                        must(raw.startswith(b'\x89PNG\r\n\x1a\n') and len(raw)==reply['size'] and len(raw)<8*1024*1024,'Invalid screenshot')
                        target=capture_dir/(step['label']+'.png')
                        with target.open('xb') as stream:stream.write(raw)
                        event.update(file=str(target),sha256=sha(raw));save(s)
                    guarded(a,c,s,action['alias'])
                if action['finish_to_menu']:load_once(a,c,s,action['alias'],'MENU')
                s['result']='ACTIONS_CAPTURED_FOR_HUMAN_REVIEW'
            except BaseException as error:s['result']='STOPPED';s['error']=str(error)
            finally:
                cleanup(a,c,s)
                try:device_check(c,sf,ready);s['protected_hashes_and_membership_unchanged']=True
                except BaseException as error:s['recovery_required']=(s.get('recovery_required','')+'; preservation: '+str(error)).strip('; ')
    except BaseException as error:s['result']='STOPPED';s['error']=str(error)
    finally:s['finished']=time.time();save(s)
    print(json.dumps({key:s.get(key) for key in ('result','error','recovery_required','final_state','protected_hashes_and_membership_unchanged')},indent=2))
    return 0 if s['result']=='ACTIONS_CAPTURED_FOR_HUMAN_REVIEW' and not s.get('recovery_required') else 2

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute',action='store_true');parser.add_argument('--action')
    parser.add_argument('--ready-sha256');parser.add_argument('--action-sha256');parser.add_argument('--script-sha256');args=parser.parse_args()
    if not READY.exists():
        must(not args.execute,'Root-reviewed DEVICE-READY.json does not exist')
        print(json.dumps(dict(local_only=True,no_connection=True,device_ready=False,script_sha256=sha(Path(__file__).read_bytes()))));return 0
    ready,action=verify_local(args.action)
    if not args.execute:
        print(json.dumps(dict(local_only_verified=True,no_connection=True,ready_sha256=sha(READY.read_bytes()),
            action_sha256=sha(Path(args.action).read_bytes()) if args.action else None,script_sha256=sha(Path(__file__).read_bytes()))));return 0
    must(action is not None,'Reviewed one-shot action JSON required');return execute(args,ready,action)

if __name__=='__main__':raise SystemExit(main())
