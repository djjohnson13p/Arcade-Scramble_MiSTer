"""Root-reviewed stdin session; default validates locally and never connects."""
import argparse, importlib.util, json, re, sys, time
from pathlib import Path

sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
V2_SHA='419ac74c5546bcd24d5da1168b7034bd108dc6ea588668db5e13e4a30c9195c3'

def load_api():
    import hashlib
    path=OUT/'phase_control_v2.py'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==V2_SHA,'Reviewed V2 helper changed'
    spec=importlib.util.spec_from_file_location('reviewed_phase_v2',path)
    p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p);return p

def current(p,a,c):
    state=a.state(c)
    for alias in ('MENU',*p.ALIASES):
        try:p.identity(a,state,alias,'user');return alias
        except RuntimeError:pass
    raise RuntimeError('Expected idle User on Menu or a known test alias; no action permitted')

def input_step(p,cmd):
    p.must(set(cmd)=={'op','keys','duration_ms'},'Input fields must be op/keys/duration_ms')
    keys=cmd['keys'];ms=cmd['duration_ms']
    p.must(isinstance(keys,list) and 1<=len(keys)<=4 and len(set(keys))==len(keys) and set(keys)<=p.KEYS,'Invalid keys/combo')
    p.must(not {'left','right'}<=set(keys) and not {'up','down'}<=set(keys),'Opposite directions are not permitted')
    p.must(type(ms) is int and 1<=ms<=5000,'Duration must be 1..5000ms')
    return {'kind':'input','keys':keys,'duration_ms':ms}

def run(args,p,ready):
    p.must(ready['_loaded_sha256']==args.ready_sha256 and p.sha(Path(__file__).read_bytes())==args.script_sha256,'Reviewed ready/script hash mismatch')
    p.must(re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',args.session_id or '') is not None,'Safe unique session ID required')
    folder=OUT/'session-journals';folder.mkdir(exist_ok=True);journal=folder/(args.session_id+'.json')
    s={'_journal':str(journal),'session_id':args.session_id,'ready_sha256':args.ready_sha256,'script_sha256':args.script_sha256,
       'started':time.time(),'events':[],'commands':[],'alias':'MENU','finish_to_menu':False,'result':'STARTED_DO_NOT_REPEAT'}
    with journal.open('x',encoding='utf-8') as stream:json.dump(s,stream)
    captures=folder/args.session_id;captures.mkdir();keyboard_alias=None;last_input=0
    try:
        a=p.transport_api()
        with a.device() as (c,sf):
            sf.get_channel().settimeout(30)
            try:
                current(p,a,c);p.device_check(c,sf,ready);s['device_verified_at_start']=True;p.save(s)
                print(json.dumps({'session_ready':True,'session_id':args.session_id}),flush=True)
                for line in sys.stdin:
                    cmd=json.loads(line);op=cmd['op'];p.must(op in ('load','input','screenshot','finish','close'),'Unknown command')
                    s['commands'].append({'command':cmd,'started':time.time()});p.save(s)
                    if op=='close':p.must(set(cmd)=={'op'},'Close takes no other fields');break
                    alias=current(p,a,c);step=input_step(p,cmd) if op=='input' else None
                    if op=='load':p.must(set(cmd)=={'op','alias'} and cmd['alias'] in p.ALIASES,'Load requires one known alias')
                    if op=='finish':p.must(set(cmd)=={'op'} and alias!='MENU','Finish requires a known test alias')
                    if op=='input':p.must(alias!='MENU','Game input is not permitted in Menu')
                    if op=='screenshot':
                        p.must(set(cmd)<=set(('op','label','settle_ms')) and re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',cmd.get('label','')) is not None,'Invalid screenshot label/fields')
                        p.must(type(cmd.get('settle_ms',0)) is int and 0<=cmd.get('settle_ms',0)<=5000,'Settle must be 0..5000ms')
                    for name in ('epoch','load_attempted','neutral_initialization_attempted'):s.pop(name,None)
                    s.update(alias=cmd['alias'] if op=='load' else alias,finish_to_menu=op=='finish',result='COMMAND_STARTED',_deadline=time.monotonic()+180)
                    try:
                        p.identity(a,a.state(c),alias,'user');s['handoff_attempted']=True;p.save(s)
                        h=p.wire(c,s,{'mister':'control','action':'assistant'},'command-assistant-handoff')
                        if h.get('success') is True and h.get('mode')=='assistant' and h.get('epoch'):s['epoch']=h['epoch'];p.save(s)
                        p.must(a.idle(h,'assistant'),'Assistant handoff is not idle');p.guarded(a,c,s,alias)
                        if op in ('load','finish'):
                            p.load_once(a,c,s,alias,'MENU' if op=='finish' else s['alias']);keyboard_alias=None;last_input=0
                        elif op=='input':
                            if keyboard_alias!=alias or time.monotonic()-last_input>90:p.initialize_for_inputs(a,c,s,[step]);keyboard_alias=alias
                            state=p.guarded(a,c,s,alias);type(c).request.__globals__['preflight_input'](state['control'],step['duration_ms'])
                            payload={'mister':'input','device':'keyboard','duration_ms':step['duration_ms']}
                            payload['key' if len(step['keys'])==1 else 'combo']=step['keys'][0] if len(step['keys'])==1 else step['keys']
                            r=p.wire(c,s,payload,'session-timed-input')
                            p.must(r.get('success') is True and r.get('status')=='completed' and r.get('action_id')==r.get('id'),'Input uncertain; no replay')
                            p.guarded(a,c,s,alias);last_input=time.monotonic()
                        else:
                            time.sleep(cmd.get('settle_ms',0)/1000);p.guarded(a,c,s,alias)
                            event={'label':cmd['label'],'started':time.time()};s.setdefault('captures',[]).append(event);p.save(s)
                            reply=c.request({'mister':'screenshot'});p.must(reply.get('success') is True,'Screenshot failed')
                            raw=p.base64.b64decode(reply['data'],validate=True)
                            p.must(raw.startswith(b'\x89PNG\r\n\x1a\n') and len(raw)==reply['size'] and len(raw)<8*1024*1024,'Invalid screenshot')
                            path=captures/(cmd['label']+'.png')
                            with path.open('xb') as stream:stream.write(raw)
                            event.update(file=str(path),sha256=p.sha(raw));p.guarded(a,c,s,alias)
                        s['result']='ACTIONS_CAPTURED_FOR_HUMAN_REVIEW'
                    except BaseException:s['result']='STOPPED';raise
                    finally:p.cleanup(a,c,s);p.save(s)
                    p.must(not s.get('recovery_required'),'Cleanup uncertain; session stopped')
                    print(json.dumps({'command_completed':op,'alias':s['alias'],'user_control':True,'gameplay_pass':False}),flush=True)
            finally:
                p.cleanup(a,c,s)
                try:
                    closing,_=p.verify_local();p.must(closing['_loaded_sha256']==args.ready_sha256 and p.sha((OUT/'phase_control_v2.py').read_bytes())==V2_SHA and p.sha(Path(__file__).read_bytes())==args.script_sha256,'Ready/helper/session bytes changed during session');s['local_bindings_verified_at_close']=True
                except BaseException as error:s['recovery_required']='Close local integrity: '+str(error)
                try:p.device_check(c,sf,ready);s['device_verified_at_close']=True
                except BaseException as error:s['recovery_required']=s.get('recovery_required','')+'; close preservation: '+str(error)
    except BaseException as error:s['result']='STOPPED';s['error']=str(error)
    finally:s['finished']=time.time();p.save(s)
    print(json.dumps({key:s.get(key) for key in ('result','error','recovery_required','device_verified_at_close','final_state')}),flush=True)
    return 2 if s.get('error') or s.get('recovery_required') else 0

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--execute',action='store_true')
    parser.add_argument('--ready-sha256');parser.add_argument('--script-sha256');parser.add_argument('--session-id');args=parser.parse_args()
    p=load_api()
    if not p.READY.exists():p.must(not args.execute,'DEVICE-READY.json missing');print(json.dumps({'local_only':True,'no_connection':True,'device_ready':False}));return 0
    ready,_=p.verify_local()
    if not args.execute:print(json.dumps({'local_only_verified':True,'no_connection':True,'script_sha256':p.sha(Path(__file__).read_bytes())}));return 0
    return run(args,p,ready)

if __name__=='__main__':raise SystemExit(main())
